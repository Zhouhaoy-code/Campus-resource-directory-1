import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Flame, UserCheck, Shield, GraduationCap, Compass, HelpCircle, HeartHandshake, Eye, BookOpen, Layers } from 'lucide-react';
import P5Background from './components/P5Background';
import ResourceCard from './components/ResourceCard';
import CallingCardEmergency from './components/CallingCardEmergency';
import LostFoundSection from './components/LostFoundSection';
import { presetResources } from './data';

export default function App() {
  const [activeTab, setActiveTab] = useState<'directory' | 'lost_found'>('directory');
  const [studentQuoteIdx, setStudentQuoteIdx] = useState(0);

  // Cool custom quotes reflecting student happiness and connectivity
  const studentQuotes = [
    '“A diverse campus thrives on collaboration. Keep your belongings secured and your heart open!” — Grade 12 Advisor',
    '“Found my lost Math calculator in Room H304 in just 10 minutes. This portal is absolute magic!” — Emily W. (Grade 10)',
    '“If you are feeling overwhelmed by classes or IB deadlines, Counselor Sarah has the ultimate dialogue tree.” — Anon Tiger',
    '“Service CAS groups meet every Tuesday in the Global citizens lounge. Join the alliance today!” — CAS Liaison'
  ];

  const rotateQuote = () => {
    setStudentQuoteIdx((prev) => (prev + 1) % studentQuotes.length);
  };

  return (
    <div className="relative min-h-screen pb-20 overflow-x-hidden">
      {/* 1. ANIMATED CANVAS BACKGROUND */}
      <P5Background />

      {/* 2. TOP EDGE STYLIZED BANNER / TAPE DECORATION */}
      <div className="bg-danger-stripes h-4 w-full border-b-2 border-white select-none pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* 3. HERO CORNER STYLIZED LOGO & CHRONO MODULE */}
        <header className="relative flex flex-col lg:flex-row items-stretch justify-between gap-6 mb-8 mt-4">
          
          {/* Main Visual Title Header */}
          <div className="relative bg-p5-pure border-4 border-p5-light p-6 md:p-8 flex-grow clip-slant-right shadow-p5-red">
            {/* Corner Decorative Badge */}
            <div className="absolute top-0 right-0 bg-p5-red text-white text-[10px] font-mono font-bold px-4 py-1 uppercase tracking-widest border-l-2 border-b-2 border-p5-light select-none">
              ★ SYSTEM VERSION: O-B-S 5 ★
            </div>
            
            <div className="flex items-center gap-4">
              <div className="bg-p5-red p-3 border-2 border-p5-light rotate-[-4deg] animate-pulse-star select-none shrink-0">
                <GraduationCap className="w-8 h-8 text-white stroke-[2.5]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono bg-zinc-900 border border-zinc-700 px-2 py-0.5 text-p5-yellow font-bold uppercase tracking-wider">
                    Beijing WAB Academy
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500 uppercase">
                    ★ COGNITIVE DIRECTORY
                  </span>
                </div>
                <h1 className="font-bebas text-5xl md:text-6xl text-white tracking-widest uppercase leading-none mt-1 select-none">
                  WAB CAMPUS <span className="text-p5-red">RECOVERY</span> & RESOURCE HUB
                </h1>
              </div>
            </div>

            <p className="text-xs text-zinc-400 mt-4 leading-relaxed font-sans max-w-3xl">
              Welcome to the centralized community portal for the Western Academy of Beijing. 
              Built with a sleek high-contrast aesthetic, this mobile-friendly platform connects students to counselors, tech supports, library assets, CAS associations, and a specialized lost-and-found registry to maximize campus security and student connectivity.
            </p>
          </div>

          {/* Right Floating Character Dialogue Status Box */}
          <div className="lg:w-80 bg-p5-red border-4 border-p5-light p-5 relative overflow-hidden flex flex-col justify-between clip-slant-left shadow-p5-black">
            <div className="absolute -right-6 -bottom-6 text-black opacity-10 text-9xl font-extrabold select-none">
              ★
            </div>

            <div className="relative z-10">
              <div className="flex items-center justify-between text-xs font-mono text-black font-extrabold mb-2 border-b border-black/30 pb-1.5">
                <span>TIGER INTEL STATS</span>
                <span className="animate-pulse">● BEIJING LIVE</span>
              </div>

              <div className="space-y-1.5 text-black font-bold text-xs font-sans">
                <div className="flex justify-between">
                  <span>Student Safe Index:</span>
                  <span className="font-mono text-white text-[11px] bg-black px-1.5">100% MAX SEAL</span>
                </div>
                <div className="flex justify-between">
                  <span>Counselors Active:</span>
                  <span className="font-mono text-white text-[11px] bg-black px-1.5 font-bold">2 LIVES ACTIVE</span>
                </div>
                <div className="flex justify-between">
                  <span>Found Recovery:</span>
                  <span className="font-mono text-p5-yellow text-[11px] bg-black px-1.5 font-bold">★ LIVE AUTO-MATCH</span>
                </div>
              </div>
            </div>

            {/* Micro quote carousel */}
            <div 
              onClick={rotateQuote}
              className="mt-4 bg-black text-p5-light p-2.5 border border-p5-light cursor-pointer hover:bg-neutral-900 transition-colors select-none text-[10px] leading-relaxed font-sans font-medium"
            >
              <p className="line-clamp-3">{studentQuotes[studentQuoteIdx]}</p>
              <div className="text-right text-[8px] font-mono text-p5-red mt-1 uppercase font-bold">
                CLICK TO ROTATE MIND MATRIX
              </div>
            </div>
          </div>

        </header>

        {/* 4. EMERGENCY CALLING TICKER (Always on top for seamless onboarding access) */}
        <CallingCardEmergency />

        {/* 5. HIGH CONTRAST TAB SELECTION SYSTEM (Persona 5 Jagged Cut out style) */}
        <section className="relative mt-8 select-none">
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start items-stretch">
            
            {/* Tab 1: Directory */}
            <button
              id="tab-btn-directory"
              onClick={() => setActiveTab('directory')}
              className={`relative py-4 px-8 font-bebas text-2xl tracking-widest uppercase transition-all duration-200 cursor-pointer text-center flex-1 sm:flex-none flex items-center justify-center gap-2 ${
                activeTab === 'directory'
                  ? 'bg-p5-red text-p5-pure font-extrabold border-4 border-p5-light shadow-p5-white shadow-p5-glow transform -rotate-1 -translate-y-1'
                  : 'bg-p5-card text-zinc-400 hover:text-white border-2 border-zinc-800 hover:border-p5-red hover:shadow-p5-glow'
              }`}
            >
              <Compass className={`w-5 h-5 ${activeTab === 'directory' ? 'text-white shrink-0' : 'text-zinc-500 shrink-0'}`} />
              ★ CAMPUS RESOURCE DIRECTORY ★
            </button>

            {/* Tab 2: Lost & Found */}
            <button
              id="tab-btn-lostfound"
              onClick={() => setActiveTab('lost_found')}
              className={`relative py-4 px-8 font-bebas text-2xl tracking-widest uppercase transition-all duration-200 cursor-pointer text-center flex-1 sm:flex-none flex items-center justify-center gap-2 ${
                activeTab === 'lost_found'
                  ? 'bg-p5-red text-p5-pure font-extrabold border-4 border-p5-light shadow-p5-white shadow-p5-glow transform rotate-1 -translate-y-1'
                  : 'bg-p5-card text-zinc-400 hover:text-white border-2 border-zinc-800 hover:border-p5-red hover:shadow-p5-glow'
              }`}
            >
              <Layers className={`w-5 h-5 ${activeTab === 'lost_found' ? 'text-p5-yellow shrink-0 animate-bounce' : 'text-zinc-500 shrink-0'}`} />
              ☆ STUDENT LOST & FOUND bulletins ☆
            </button>

          </div>
        </section>

        {/* 6. TAB CONTENT GRID */}
        <main className="mt-8">
          <AnimatePresence mode="wait">
            {activeTab === 'directory' ? (
              <motion.div
                key="directory-tab"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 30 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                {/* Visual Header */}
                <div className="flex items-center gap-3 border-b-2 border-zinc-800 pb-3 mb-6 select-none">
                  <div className="p-1 px-3.5 bg-p5-yellow text-p5-dark text-xs font-mono font-extrabold clip-badge rotate-[-2deg]">
                    ★ EXPEDITE INFO INDEX ★
                  </div>
                  <h2 className="font-bebas text-3xl uppercase tracking-wider text-white">
                    Centralized Alliance Resources
                  </h2>
                </div>

                <p className="text-sm text-zinc-400 max-w-4xl font-sans mb-8 leading-relaxed">
                  Click on any service card below to summon detailed dossiers. 
                  Each hub block provides immediate hotlines, location tracking, and an interactive booking system to secure physical assistance.
                </p>

                {/* Grid layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {presetResources.map((resource) => (
                    <div key={resource.id}>
                      <ResourceCard resource={resource} />
                    </div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="lost-found-tab"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
              >
                <LostFoundSection />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* 7. VISUALLY IMPRESSIVE FOOTER */}
        <footer className="mt-20 border-t-4 border-p5-light pt-8 select-none text-center relative overflow-hidden bg-p5-pure py-8 px-4">
          <div className="absolute top-0 bottom-0 left-0 right-0 bg-dots opacity-10" />
          <div className="relative z-10 max-w-3xl mx-auto space-y-3">
            <h4 className="font-bebas text-3xl text-p5-red tracking-widest uppercase">
              ★ BEIJING WAB COMMUNITY SHIELD ★
            </h4>
            <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest leading-relaxed">
              Western Academy of Beijing. This platform operates independently in service of high school onboarding convenience, seamless property recovery and digital happiness.
            </p>
            <div className="flex justify-center gap-4 text-xs font-mono text-p5-yellow font-extrabold">
              <span>★ TAKING THE PROPERTY SECURE ★</span>
              <span>☆ COGNITIVE RESOLUTION ☆</span>
            </div>
            <p className="text-[10px] text-zinc-600 font-mono pt-4 border-t border-zinc-900">
              © {new Date().getFullYear()} WAB Phantom Network. Styled with extreme honor.
            </p>
          </div>
        </footer>

      </div>
    </div>
  );
}
