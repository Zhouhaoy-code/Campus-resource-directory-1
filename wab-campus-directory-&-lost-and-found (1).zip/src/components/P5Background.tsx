import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';

export default function P5Background() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Normalize to -50 to 50
      const x = (e.clientX / window.innerWidth - 0.5) * 40;
      const y = (e.clientY / window.innerHeight - 0.5) * 40;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="fixed inset-0 -z-50 overflow-hidden bg-p5-dark select-none pointer-events-none">
      {/* Absolute Noir Base with subtle halftone grids */}
      <div className="absolute inset-0 bg-dots opacity-40" />

      {/* Extreme Slanted Velvet Red Accent Bars */}
      <motion.div 
        className="absolute -left-20 -top-40 w-1/3 h-[180%] bg-p5-red/30 mix-blend-color-dodge origin-top-left"
        animate={{
          rotate: [-15, -12, -15],
          skewX: [-10, -5, -10],
          x: mousePos.x * 0.4,
          y: mousePos.y * 0.4,
        }}
        transition={{
          rotate: { duration: 12, repeat: Infinity, ease: "easeInOut" },
          skewX: { duration: 10, repeat: Infinity, ease: "easeInOut" },
          type: "spring",
          stiffness: 45,
          damping: 20
        }}
      />

      <motion.div 
        className="absolute -right-40 -bottom-40 w-1/2 h-[150%] bg-black/80 mix-blend-multiply origin-bottom-right"
        animate={{
          rotate: [12, 16, 12],
          skewX: [5, 12, 5],
          x: mousePos.x * -0.3,
          y: mousePos.y * -0.3,
        }}
        transition={{
          rotate: { duration: 15, repeat: Infinity, ease: "easeInOut" },
          skewX: { duration: 12, repeat: Infinity, ease: "easeInOut" },
          type: "spring",
          stiffness: 40,
          damping: 25
        }}
      />

      {/* Floating Star Elements (Iconic Persona 5 symbols) */}
      <div className="absolute inset-0 opacity-25">
        {/* Star 1 */}
        <motion.div 
          className="absolute left-[15%] top-[25%] text-p5-red font-bold text-4xl"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.2, 1],
            y: [0, -15, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          ★
        </motion.div>

        {/* Star 2 */}
        <motion.div 
          className="absolute right-[20%] top-[15%] text-white font-bold text-6xl"
          animate={{
            rotate: [180, -180],
            scale: [1, 1.3, 1],
            y: [0, 20, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          ☆
        </motion.div>

        {/* Star 3 - Solid mini star */}
        <motion.div 
          className="absolute left-[45%] bottom-[20%] text-p5-yellow font-bold text-3xl"
          animate={{
            scale: [0.8, 1.2, 0.8],
            rotate: [10, 45, 10],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          ★
        </motion.div>

        {/* Star 4 */}
        <motion.div 
          className="absolute right-[10%] bottom-[35%] text-p5-red font-bold text-5xl"
          animate={{
            rotate: [0, 45, 0],
            scale: [1, 1.15, 1],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          ★
        </motion.div>
      </div>

      {/* Red Ambient Splatters / Radial Glows */}
      <div className="absolute top-[40%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] rounded-full bg-p5-red/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[10%] w-[500px] h-[400px] rounded-full bg-p5-yellow/5 blur-[100px] pointer-events-none" />
    </div>
  );
}
